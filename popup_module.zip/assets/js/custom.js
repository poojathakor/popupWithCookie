$(document).ready(function(){

/* ###################################################################################################
Extra Function
 ###################################################################################################*/
 function validateEmail(email) {
    var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
    if (filter.test(email)) {
        return true;
    }else{
        return false;
    }
}

/* ###################################################################################################
Pop up Module
###################################################################################################### */
if($(".body_cls").find(".popup_module").length !=0){
    // $coo = $.cookie('emailaddress');
     $( document ).ready(function() {
        var close_coo = $.cookie('close');
        console.log(close_coo);
        if($.cookie('emailaddress') == null && $.cookie('close') != "yes"){
            $('.popup_module').delay(2000).fadeIn(100);
        }
        else{
             $('.popup_module').css("display","none");
        }
    });
    $("#close_popup").click(function(){
        var d = new Date();
        console.log("today "+ d);
        var tomo = new Date(d.getTime() + 24 * 60 * 60 * 1000);
        var tomo_date = tomo.getDate();
        var tomo_month = tomo.getMonth();
        var tomo_year = tomo.getFullYear();
        var tomo_hr= tomo.getHours();
        var tomo_min = tomo.getMinutes();
        var tomo_sec = tomo.getSeconds();
        // console.log(" tomo date:" + tomo_date+" tomo month: "+tomo_month+" tomo year:  "+tomo_year+" tomo hr "+tomo_hr+" tomo min "+tomo_min+" tomo sec: "+tomo_sec);
        $.cookie("close", "yes", {expires: new Date(tomo_year, tomo_month, tomo_date, tomo_hr, tomo_min, tomo_sec)});
        // $.cookie("close", "yes", {expires: new Date(2018, 3, 12, 10, 19, 00)});
        $('.popup_module').css("display","none");
        // var clos_coo = $.cookie("close");
        // console.log(clos_coo);
    });
    $("input[type='submit']").on('click' ,function(event){
        event.preventDefault();
        if (validateEmail($("#email").val()) == "" || ($("#email").val()) == "") {
            $("#email").addClass("error_cls");
            $(".email-error").html("Please enter valid email address");
            // event.preventDefault();
            return false;
        }
        else{
                $.ajax({
                url: 'email.json',
                type: 'GET',
                dataType: 'json',
                
                success: function( resp ) {
                    for(var i = 0; i < resp.users.length; i++)
                    {
                       // console.log(resp.users[i].email);
                        if($("#email").val() == resp.users[i].email)
                        {
                            $(".email-error").html("its not an unique email address!");
                            return false;
                        }
                        else
                        {
                            var email = $("#email").val(); 
                            console.log(email);
                            $.cookie('emailaddress', email);
                            $(".popup_module").hide();
                        }
                    }
                   
                },
                error: function( req, status, err ) {
                    alert( 'something went wrong', status, err );
                }
            });
        }
    }); 
    $("#email").on("keydown",function(){
        if (validateEmail($("#email").val()) != ""){
            $("#email").removeClass("error_cls");
            $(".email-error").empty();
        }
    });
}

});